using UnityEngine;
using System.Collections.Generic;
using System;

namespace GrandRoleplay.Inventory
{
    [Serializable]
    public class Item
    {
        public int id;
        public string name;
        public int quantity;
        public float weight;
        public int modelId;
    }

    public class InventoryManager : MonoBehaviour
    {
        public static InventoryManager Instance;
        public List<Item> items = new List<Item>();
        public int maxSlots = 20;
        public float currentWeight = 0;
        public float maxWeight = 50.0f;

        private void Awake()
        {
            Instance = this;
        }

        public bool AddItem(string name, int qty, int modelId, float weightPerItem)
        {
            Item existing = items.Find(x => x.name == name);
            if (existing != null)
            {
                existing.quantity += qty;
            }
            else
            {
                if (items.Count >= maxSlots) return false;
                items.Add(new Item { name = name, quantity = qty, modelId = modelId, weight = weightPerItem });
            }
            
            currentWeight += weightPerItem * qty;
            OnInventoryUpdated?.Invoke();
            return true;
        }

        public void RemoveItem(string name, int qty)
        {
            Item existing = items.Find(x => x.name == name);
            if (existing != null)
            {
                existing.quantity -= qty;
                currentWeight -= existing.weight * qty;
                if (existing.quantity <= 0) items.Remove(existing);
                OnInventoryUpdated?.Invoke();
            }
        }

        public event Action OnInventoryUpdated;
    }
}
