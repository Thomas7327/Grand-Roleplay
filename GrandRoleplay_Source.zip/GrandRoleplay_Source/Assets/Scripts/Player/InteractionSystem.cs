using UnityEngine;
using GrandRoleplay.Vehicles;

namespace GrandRoleplay.Player
{
    public class InteractionSystem : MonoBehaviour
    {
        public float interactRange = 3f;
        public LayerMask interactableLayer;
        
        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.E) || /* Mobile Button */ false)
            {
                TryInteract();
            }
        }

        public void TryInteract()
        {
            Collider[] colliders = Physics.OverlapSphere(transform.position, interactRange, interactableLayer);
            foreach (var col in colliders)
            {
                // Logic for Vehicle
                if (col.CompareTag("Vehicle"))
                {
                    EnterVehicle(col.GetComponent<VehicleController>());
                    break;
                }
                
                // Logic for NPC
                if (col.CompareTag("NPC"))
                {
                    TalkToNPC(col.gameObject);
                    break;
                }
            }
        }

        void EnterVehicle(VehicleController vehicle)
        {
            Debug.Log("Entering Vehicle...");
            // Attach player to vehicle, disable player controller, enable vehicle controller
        }

        void TalkToNPC(GameObject npc)
        {
            Debug.Log("Talking to NPC...");
            // Open Dialog UI
        }
    }
}
