using UnityEngine;
using UnityEngine.UI;

namespace GrandRoleplay.Player
{
    public class PlayerController : MonoBehaviour
    {
        [Header("Movement Settings")]
        public float moveSpeed = 5.0f;
        public float runSpeed = 8.0f;
        public float rotationSpeed = 720f;
        public float gravity = -9.81f;
        public float jumpHeight = 1.5f;

        [Header("References")]
        public CharacterController controller;
        public Animator animator;
        public Transform cameraTransform;

        [Header("Mobile Controls")]
        public FixedJoystick moveJoystick;
        public FixedJoystick lookJoystick;
        public Button jumpButton;
        public Button interactButton;

        private Vector3 velocity;
        private bool isGrounded;
        private float currentSpeed;

        private void Start()
        {
            if (controller == null) controller = GetComponent<CharacterController>();
            if (animator == null) animator = GetComponent<Animator>();
            if (cameraTransform == null) cameraTransform = Camera.main.transform;
            
            currentSpeed = moveSpeed;
        }

        private void Update()
        {
            HandleMovement();
            HandleGravity();
            UpdateAnimation();
        }

        private void HandleMovement()
        {
            isGrounded = controller.isGrounded;

            float horizontal = moveJoystick.Horizontal;
            float vertical = moveJoystick.Vertical;

            Vector3 direction = new Vector3(horizontal, 0, vertical).normalized;

            if (direction.magnitude >= 0.1f)
            {
                // Calculate rotation based on camera
                float targetAngle = Mathf.Atan2(direction.x, direction.z) * Mathf.Rad2Deg + cameraTransform.eulerAngles.y;
                float angle = Mathf.SmoothDampAngle(transform.eulerAngles.y, targetAngle, ref rotationSpeed, 0.1f);
                transform.rotation = Quaternion.Euler(0f, angle, 0f);

                Vector3 moveDir = Quaternion.Euler(0f, targetAngle, 0f) * Vector3.forward;
                controller.Move(moveDir.normalized * currentSpeed * Time.deltaTime);
            }
        }

        private void HandleGravity()
        {
            if (isGrounded && velocity.y < 0)
            {
                velocity.y = -2f;
            }

            velocity.y += gravity * Time.deltaTime;
            controller.Move(velocity * Time.deltaTime);
        }

        public void Jump()
        {
            if (isGrounded)
            {
                velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
                animator.SetTrigger("Jump");
            }
        }

        private void UpdateAnimation()
        {
            float moveMagnitude = new Vector2(moveJoystick.Horizontal, moveJoystick.Vertical).magnitude;
            animator.SetFloat("Speed", moveMagnitude * currentSpeed);
            animator.SetBool("IsGrounded", isGrounded);
        }
    }
}
