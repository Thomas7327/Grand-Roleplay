using UnityEngine;
using System.Collections;
using GrandRoleplay.Economy;

namespace GrandRoleplay.Jobs
{
    public enum JobType
    {
        Unemployed = 0,
        Farmer = 1,
        Miner = 2,
        Trucker = 3,
        Police = 10,
        EMS = 11
    }

    public class JobManager : MonoBehaviour
    {
        public static JobManager Instance;
        
        [Header("Job Status")]
        public JobType currentJob = JobType.Unemployed;
        public bool isWorking = false;

        private void Awake()
        {
            Instance = this;
        }

        public void StartJob(JobType job)
        {
            currentJob = job;
            isWorking = true;
            Debug.Log("Started job: " + job.ToString());
            // Logic to spawn job equipment or UI
        }

        public void CompleteAction(int reward)
        {
            if (!isWorking) return;
            EconomyManager.Instance.AddCash(reward);
            // Add EXP logic
        }

        public void QuitJob()
        {
            isWorking = false;
            currentJob = JobType.Unemployed;
        }
    }
}
