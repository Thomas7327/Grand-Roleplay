using UnityEngine;

namespace GrandRoleplay.Optimization
{
    public class MobileOptimizer : MonoBehaviour
    {
        public enum QualityLevel { Low, Medium, High }
        public QualityLevel currentQuality = QualityLevel.Medium;

        void Start()
        {
            ApplySettings();
        }

        public void SetQuality(int level)
        {
            currentQuality = (QualityLevel)level;
            ApplySettings();
        }

        void ApplySettings()
        {
            switch (currentQuality)
            {
                case QualityLevel.Low:
                    QualitySettings.SetQualityLevel(0);
                    Application.targetFrameRate = 30;
                    Camera.main.farClipPlane = 150f;
                    break;
                case QualityLevel.Medium:
                    QualitySettings.SetQualityLevel(2);
                    Application.targetFrameRate = 60;
                    Camera.main.farClipPlane = 300f;
                    break;
                case QualityLevel.High:
                    QualitySettings.SetQualityLevel(4);
                    Application.targetFrameRate = 60;
                    Camera.main.farClipPlane = 600f;
                    break;
            }
        }
    }
}
