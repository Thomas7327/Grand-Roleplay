using UnityEngine;
using System;
using System.Collections.Generic;

namespace GrandRoleplay.Economy
{
    [Serializable]
    public class PlayerStats
    {
        public string characterName;
        public long cash;
        public long bank;
        public int jobId;
        public int factionId;
        public int level;
        public int exp;
        public List<InventoryItem> inventory = new List<InventoryItem>();
    }

    [Serializable]
    public class InventoryItem
    {
        public int itemId;
        public string itemName;
        public int quantity;
    }

    public class EconomyManager : MonoBehaviour
    {
        public static EconomyManager Instance;
        public PlayerStats stats;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);
            
            LoadData();
        }

        public void AddCash(long amount)
        {
            stats.cash += amount;
            SaveData();
            Events.OnEconomyChanged?.Invoke();
        }

        public bool RemoveCash(long amount)
        {
            if (stats.cash >= amount)
            {
                stats.cash -= amount;
                SaveData();
                Events.OnEconomyChanged?.Invoke();
                return true;
            }
            return false;
        }

        public void SaveData()
        {
            string json = JsonUtility.ToJson(stats);
            PlayerPrefs.SetString("PlayerStats", json);
            PlayerPrefs.Save();
        }

        public void LoadData()
        {
            if (PlayerPrefs.HasKey("PlayerStats"))
            {
                string json = PlayerPrefs.GetString("PlayerStats");
                stats = JsonUtility.FromJson<PlayerStats>(json);
            }
            else
            {
                stats = new PlayerStats { characterName = "New Player", cash = 500, bank = 1000 };
            }
        }
    }

    public static class Events
    {
        public static Action OnEconomyChanged;
    }
}
