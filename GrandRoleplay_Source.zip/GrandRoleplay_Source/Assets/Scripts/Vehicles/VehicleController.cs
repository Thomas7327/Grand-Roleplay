using UnityEngine;

namespace GrandRoleplay.Vehicles
{
    public class VehicleController : MonoBehaviour
    {
        [Header("Vehicle Settings")]
        public float motorForce = 1500f;
        public float breakForce = 3000f;
        public float maxSteerAngle = 30f;

        [Header("Wheel Colliders")]
        public WheelCollider frontLeftWheel;
        public WheelCollider frontRightWheel;
        public WheelCollider rearLeftWheel;
        public WheelCollider rearRightWheel;

        [Header("Wheel Transforms")]
        public Transform frontLeftTransform;
        public Transform frontRightTransform;
        public Transform rearLeftTransform;
        public Transform rearRightTransform;

        private float horizontalInput;
        private float verticalInput;
        private bool isBreaking;

        // Mobile Control Inputs
        public void SetInputs(float horizontal, float vertical, bool breaking)
        {
            horizontalInput = horizontal;
            verticalInput = vertical;
            isBreaking = breaking;
        }

        [Header("Vehicle Stats")]
        public float fuel = 100f;
        public float fuelConsumption = 0.05f;
        public float health = 1000f;
        public bool engineOn = false;

        private void FixedUpdate()
        {
            if (engineOn && fuel > 0)
            {
                HandleMotor();
                HandleSteering();
                ConsumeFuel();
            }
            else
            {
                ApplyBreaking(breakForce);
            }
            UpdateWheels();
        }

        private void ConsumeFuel()
        {
            if (verticalInput != 0)
            {
                fuel -= fuelConsumption * Time.fixedDeltaTime;
                if (fuel <= 0)
                {
                    fuel = 0;
                    engineOn = false;
                }
            }
        }

        public void ToggleEngine()
        {
            if (fuel > 0) engineOn = !engineOn;
        }

        private void OnCollisionEnter(Collision collision)
        {
            float impact = collision.relativeVelocity.magnitude;
            if (impact > 5f)
            {
                health -= impact * 10f;
                if (health <= 0)
                {
                    engineOn = false;
                    // Visual effect for explosion/smoke
                }
            }
        }

        private void HandleMotor()
        {
            frontLeftWheel.motorTorque = verticalInput * motorForce;
            frontRightWheel.motorTorque = verticalInput * motorForce;

            float currentbreakForce = isBreaking ? breakForce : 0f;
            ApplyBreaking(currentbreakForce);
        }

        private void ApplyBreaking(float force)
        {
            frontLeftWheel.brakeTorque = force;
            frontRightWheel.brakeTorque = force;
            rearLeftWheel.brakeTorque = force;
            rearRightWheel.brakeTorque = force;
        }

        private void HandleSteering()
        {
            float steerAngle = maxSteerAngle * horizontalInput;
            frontLeftWheel.steerAngle = steerAngle;
            frontRightWheel.steerAngle = steerAngle;
        }

        private void UpdateWheels()
        {
            UpdateSingleWheel(frontLeftWheel, frontLeftTransform);
            UpdateSingleWheel(frontRightWheel, frontRightTransform);
            UpdateSingleWheel(rearLeftWheel, rearLeftTransform);
            UpdateSingleWheel(rearRightWheel, rearRightTransform);
        }

        private void UpdateSingleWheel(WheelCollider wheelCollider, Transform wheelTransform)
        {
            Vector3 pos;
            Quaternion rot;
            wheelCollider.GetWorldPose(out pos, out rot);
            wheelTransform.rotation = rot;
            wheelTransform.position = pos;
        }
    }
}
