using UnityEngine;
using System.Collections.Generic;

namespace GrandRoleplay.Factions
{
    public enum FactionType
    {
        None = 0,
        Police = 1,
        Medic = 2,
        Mafia = 3,
        Gang = 4
    }

    public class FactionManager : MonoBehaviour
    {
        public static FactionManager Instance;
        
        public FactionType playerFaction = FactionType.None;
        public int factionRank = 0;

        private void Awake()
        {
            Instance = this;
        }

        public void JoinFaction(FactionType faction)
        {
            playerFaction = faction;
            factionRank = 1;
            Debug.Log("Joined Faction: " + faction.ToString());
        }

        public bool HasPermission(int requiredRank)
        {
            return factionRank >= requiredRank;
        }

        public void SendFactionMessage(string message)
        {
            // Logic for faction chat
            Debug.Log($"[FACTION] {message}");
        }
    }
}
