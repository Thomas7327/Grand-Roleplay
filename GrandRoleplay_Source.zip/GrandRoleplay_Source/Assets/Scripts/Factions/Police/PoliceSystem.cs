using UnityEngine;
using System.Collections.Generic;
using GrandRoleplay.Economy;
using GrandRoleplay.Player;

namespace GrandRoleplay.Factions.Police
{
    public class PoliceSystem : MonoBehaviour
    {
        public static PoliceSystem Instance;

        [Header("Jail Settings")]
        public Transform jailSpawnPoint;
        public float defaultJailTime = 300f; // 5 minutes

        private void Awake()
        {
            Instance = this;
        }

        // Nexston command: /cuff [id]
        public void CuffPlayer(PlayerController target)
        {
            if (target == null) return;
            
            // Logic to disable target movement and play animation
            target.moveSpeed = 0;
            target.animator.SetBool("IsCuffed", true);
            Debug.Log($"[POLICE] Player {target.name} has been cuffed.");
        }

        // Nexston command: /uncuff [id]
        public void UncuffPlayer(PlayerController target)
        {
            if (target == null) return;
            
            target.moveSpeed = 5.0f; // Restore speed
            target.animator.SetBool("IsCuffed", false);
            Debug.Log($"[POLICE] Player {target.name} has been uncuffed.");
        }

        // Nexston command: /arrest [id] [time] [fine]
        public void ArrestPlayer(PlayerController target, float time, long fine)
        {
            if (target == null) return;

            // Teleport to jail
            target.transform.position = jailSpawnPoint.position;
            
            // Deduct fine
            EconomyManager.Instance.RemoveCash(fine);
            
            // Set jail timer logic
            Debug.Log($"[POLICE] Player {target.name} arrested for {time} seconds. Fine: ${fine}");
        }

        public void OpenMDC()
        {
            // Logic to open Mobile Data Computer UI
            Debug.Log("[POLICE] Opening MDC...");
        }
    }
}
