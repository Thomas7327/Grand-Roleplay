using UnityEngine;
using System.Collections.Generic;

namespace GrandRoleplay.World
{
    public class CityGenerator : MonoBehaviour
    {
        public GameObject roadPrefab;
        public GameObject buildingPrefab;
        public int citySize = 10;
        public float cellSize = 20f;

        void Start()
        {
            GenerateCity();
        }

        void GenerateCity()
        {
            for (int x = 0; x < citySize; x++)
            {
                for (int z = 0; z < citySize; z++)
                {
                    Vector3 pos = new Vector3(x * cellSize, 0, z * cellSize);
                    
                    // Simple grid: every 3rd cell is a road
                    if (x % 3 == 0 || z % 3 == 0)
                    {
                        Instantiate(roadPrefab, pos, Quaternion.identity, transform);
                    }
                    else
                    {
                        // Place a building
                        GameObject b = Instantiate(buildingPrefab, pos, Quaternion.identity, transform);
                        b.transform.localScale = new Vector3(1, Random.Range(1, 5), 1);
                    }
                }
            }
        }
    }
}
