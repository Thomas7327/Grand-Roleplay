using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using GrandRoleplay.Economy;

namespace GrandRoleplay.UI
{
    public class MainMenuController : MonoBehaviour
    {
        [Header("Panels")]
        public GameObject loginPanel;
        public GameObject registerPanel;
        public GameObject mainMenuPanel;
        public GameObject loadingScreen;

        [Header("Input Fields")]
        public InputField usernameInput;
        public InputField passwordInput;

        [Header("Buttons")]
        public Button loginBtn;
        public Button playBtn;
        public Button settingsBtn;

        void Start()
        {
            ShowPanel(loginPanel);
            
            loginBtn.onClick.AddListener(OnLoginClicked);
            playBtn.onClick.AddListener(OnPlayClicked);
        }

        public void ShowPanel(GameObject panel)
        {
            loginPanel.SetActive(false);
            registerPanel.SetActive(false);
            mainMenuPanel.SetActive(false);
            
            panel.SetActive(true);
        }

        void OnLoginClicked()
        {
            // Simulate Login
            Debug.Log("Logging in as: " + usernameInput.text);
            ShowPanel(mainMenuPanel);
        }

        void OnPlayClicked()
        {
            loadingScreen.SetActive(true);
            SceneManager.LoadScene("MainCity");
        }

        public void QuitGame()
        {
            Application.Quit();
        }
    }
}
