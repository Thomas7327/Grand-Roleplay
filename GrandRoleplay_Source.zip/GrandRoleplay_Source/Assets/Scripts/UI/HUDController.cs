using UnityEngine;
using UnityEngine.UI;
using GrandRoleplay.Economy;
using GrandRoleplay.Vehicles;

namespace GrandRoleplay.UI
{
    public class HUDController : MonoBehaviour
    {
        [Header("Player Stats")]
        public Text cashText;
        public Text bankText;
        public Slider healthBar;
        
        [Header("Vehicle HUD")]
        public GameObject vehiclePanel;
        public Text speedText;
        public Slider fuelBar;
        public Text vehicleHealthText;

        private VehicleController currentVehicle;

        void Update()
        {
            // Update Player Info
            cashText.text = "$" + EconomyManager.Instance.stats.cash.ToString("N0");
            
            // Check if in vehicle
            if (currentVehicle != null)
            {
                vehiclePanel.SetActive(true);
                float speed = currentVehicle.GetComponent<Rigidbody>().velocity.magnitude * 3.6f; // km/h
                speedText.text = Mathf.RoundToInt(speed) + " KM/H";
                fuelBar.value = currentVehicle.fuel / 100f;
            }
            else
            {
                vehiclePanel.SetActive(false);
            }
        }

        public void SetVehicle(VehicleController vehicle)
        {
            currentVehicle = vehicle;
        }
    }
}
