# GRAND ROLEPLAY - 3D Android Open World Project

## Overview
Grand Roleplay is an original 3D Open-World Roleplay game project for Android, built using Unity Engine and C#. The core systems are adapted and modernized from the Nexston SA-MP Gamemode logic.

## Project Structure
- **Assets/Scripts/Player**: Handles 3rd-person movement, mobile touch controls (Joystick), and interactions.
- **Assets/Scripts/Vehicles**: Realistic 3D vehicle physics for Android.
- **Assets/Scripts/Economy**: Player statistics, Cash/Bank system, and local data persistence (JSON/PlayerPrefs).
- **Assets/Scripts/Jobs**: Modular job system (Farmer, Miner, Trucker, etc.) based on Nexston logic.
- **Assets/Scripts/Factions**: Faction management (Police, Medic, Gang) with rank systems.
- **Assets/Scripts/World**: Procedural city generation script for rapid map development.
- **Assets/Scripts/UI**: Modern Dark/Purple UI theme for Main Menu and HUD.

## Core Features Implemented
1. **Third-Person Mobile Controller**: Optimized for touchscreens with virtual joysticks.
2. **Economy System**: Save/Load player data, managing cash and inventory.
3. **Inventory System**: 20 slots, weight-based management, support for items like Smartphones, Radio, and Toolkits.
4. **Advanced Vehicle System**: Support for driving, braking, steering, Fuel Consumption, Engine Toggle, and Dynamic Damage.
5. **Roleplay Logic**: Adapted from Nexston (Job actions, Faction ranks, Interactions).
6. **Mobile Optimization**: Integrated quality settings (Low/Medium/High) and frame rate locking for battery efficiency.
7. **Procedural City**: A foundation for the game world.

## How to Build the APK
Since this environment is for development and analysis, you must perform the final build on a machine with Unity installed:
1. **Download** the `GrandRoleplay_Source.zip` provided.
2. **Open Unity Hub** and click "Add" to select the project folder.
3. **Set Build Target to Android**: Go to `File > Build Settings`, select `Android`, and click `Switch Platform`.
4. **Resolution/Graphics**: The scripts are already optimized for mobile performance (LOD ready).
5. **Click Build**: Generate the `.apk` file, transfer it to your Android device, and install.

## Technical Notes
- **Language**: C# (Unity).
- **Minimum Android Version**: Android 8.0 (API 26).
- **Graphics**: URP (Universal Render Pipeline) recommended for high-quality mobile visuals.

Developed by Accio Work Assistant.
